# # # # # # # # # # # # # # # # # # # # # # # # # # # #
#  Framework for Automaten en Formele Talen           #
#  Written by Robin Visser, based on work by          #
#  Bas van den Heuvel and Daan de Graaf               #
#  This work is licensed under a Creative Commons     #
#  “Attribution-ShareAlike 4.0 International”         #
#   license.                                          #
# # # # # # # # # # # # # # # # # # # # # # # # # # # #


from FA import FA


def create_fa():
    """
    Creates the finite automaton (FA) for trace verification
    """
    ### Finish the automaton here... ###
    Q = ['START', 'FD', 'ERROR']
    Sigma = ['open', 'read', 'write', 'close']
    delta = {'START': {'open': 'FD',
                       'read': 'ERROR',
                       'write': 'ERROR'},
             'FD': {'open': 'ERROR',
                    'close': 'START'}}
    s = 'START'
    F = ['ERROR']

    M = FA(Q, Sigma, delta, s, F, verbose=False)

    return M


def verify_fileio(fa, trace):
    """
    Verify proper file handling using a finite automaton (FA)
    fa:    The finite automaton
    trace: List of strings ('syscalls')
    returns: True if the trace represents proper file handling (i.e. the trace
             is NOT accepted by the FA), False otherwise
    """

    fa.reset()

    ### Your code here... ###

def main():
    """
    Create the FA and perform verification of a test trace
    """
    M = create_fa()
    ### Test your code here... ###
    trace = ["open", "read", "write", "write", "close", "open", "close"]
    print("Test trace: " + str(trace))
    print("Proper file handling: " + str(verify_fileio(M, trace)))


if __name__ == '__main__':
    main()
